﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UC_GestionPerso
{
    public delegate void ClickedWithTagHandler(UCRichButton me,object tag);

    public partial class UCRichButton : UserControl
    {
        public event ClickedWithTagHandler clickReturnTag;

        private bool _selected = false;
        public bool isSelected { set { _selected = value; } }

        public UCRichButton()
        {
            InitializeComponent();
            this.BackColor = Color.White;
        }

        public UCRichButton(string inf01) : this()
        {
            this.Width = 200;
            lblInfo1.Text = inf01;
            lblInfo1.Left = 0;
            lblInfo1.TextAlign = ContentAlignment.MiddleCenter;
            this.Controls.Remove(pictureBox1);
            this.Controls.Remove(lblInfo2);
            lblInfo1.Left = (this.Width - lblInfo1.Width)/2;
            lblInfo1.Top = 80 / 2 - lblInfo1.Height + 2;
        }

        public UCRichButton(string inf01, string inf02) : this()
        {
            lblInfo1.Text = TruncateText(inf01);
            lblInfo2.Text = TruncateText(inf02);
            this.Controls.Remove(pictureBox1);
            lblInfo1.Left = 10;
            lblInfo2.Left = lblInfo1.Left;
        }

        public UCRichButton(string inf01, string inf02, Image img) : this()
        {
            lblInfo1.Text = TruncateText(inf01);
            lblInfo2.Text = TruncateText(inf02);
            pictureBox1.Image = img;
        }


        private string TruncateText(string text, int maxLength = 15)
        {
            if(string.IsNullOrEmpty(text)) return text;
            return text.Length > maxLength ? text.Substring(0, maxLength) + "..." : text;
        }

        private void UCRichButton_Load(object sender, EventArgs e)
        {
        }

        private void UCRichButton_MouseEnter(object sender, EventArgs e)
        {
            this.BackColor = Color.Gray;
            this.ForeColor = Color.White;
        }

        private void UCRichButton_MouseLeave(object sender, EventArgs e)
        {

            if(!_selected)
            {
                this.BackColor = Color.White;
                this.ForeColor = Color.Black;
            }
        }

        private void RichButton_MouseClick(object sender, MouseEventArgs e)
        {
            clickReturnTag(this,this.Tag);
        }
    }
}
